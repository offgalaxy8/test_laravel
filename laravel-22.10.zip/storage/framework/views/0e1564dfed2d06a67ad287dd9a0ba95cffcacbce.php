<?php $__env->startSection('title_doc'); ?>Главная страница<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Главная страница</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto delectus doloremque exercitationem facilis, fugiat possimus voluptates voluptatibus! Architecto asperiores culpa dolorum laborum libero molestias, obcaecati omnis perspiciatis sit. Quae, sequi!</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
    ##parent-placeholder-b77cad1467608c98b4675073084c13ea3aba2ffb##
    <p>Дополнительный текст на главной</p>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Openserver\domains\laravel.loc\resources\views/home.blade.php ENDPATH**/ ?>
<?php $__env->startSection('aside'); ?>
<div class="aside">
    <h4>Боковая панель</h4>
    <p>Текст боковой панели</p>
    <?php echo $__env->yieldSection(); ?>
</div>
<?php /**PATH C:\Openserver\domains\laravel.loc\resources\views/inc/aside.blade.php ENDPATH**/ ?>
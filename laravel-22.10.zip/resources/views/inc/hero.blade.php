<div class="jumbotron">
    <div class="container">
        <h1>Привет всем на моем сайте!</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci debitis delectus deserunt dolore eius error est fuga ipsum labore minima porro quas, quo tenetur voluptas voluptatibus. Dignissimos quaerat quos sint?</p>
    </div>
</div>

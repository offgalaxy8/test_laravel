@extends('layouts.app')


@section('title_doc')О нас @endsection


@section('content')
    <h1>О нас</h1>
@endsection

@section('aside')
    @parent
    <p>Дополнительный текст в О нас</p>
@endsection

